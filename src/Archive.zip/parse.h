/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton interface for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     STRING = 258,
     NUMBER = 259,
     DOUBLE = 260,
     SINGLE = 261,
     INTEGER = 262,
     VARIABLE_NAME = 263,
     FUNCTION_NAME = 264,
     HEX_STR = 265,
     OCT_STR = 266,
     BIN_STR = 267,
     REM = 268,
     QUOTEREM = 269,
     BANGREM = 270,
     BYE = 271,
     CLEAR = 272,
     CLR = 273,
     DATA = 274,
     DEF = 275,
     DIM = 276,
     END = 277,
     EXIT = 278,
     FOR = 279,
     GET = 280,
     GOSUB = 281,
     GOTO = 282,
     IF = 283,
     INPUT = 284,
     LET = 285,
     LIST = 286,
     NEXT = 287,
     NEW = 288,
     OF = 289,
     ON = 290,
     PRINT = 291,
     PUT = 292,
     READ = 293,
     RESTORE = 294,
     RETURN = 295,
     RUN = 296,
     STEP = 297,
     STOP = 298,
     THEN = 299,
     TO = 300,
     USING = 301,
     WAIT = 302,
     OPEN = 303,
     CLOSE = 304,
     STATUS = 305,
     PRINT_FILE = 306,
     INPUT_FILE = 307,
     GET_FILE = 308,
     PUT_FILE = 309,
     CALL = 310,
     CLS = 311,
     CMD = 312,
     OPTION = 313,
     BASE = 314,
     PEEK = 315,
     POKE = 316,
     POP = 317,
     RANDOMIZE = 318,
     SYS = 319,
     VARLIST = 320,
     PAUSE = 321,
     INKEY = 322,
     _ABS = 323,
     SGN = 324,
     ATN = 325,
     COS = 326,
     SIN = 327,
     TAN = 328,
     CLOG = 329,
     EXP = 330,
     LOG = 331,
     SQR = 332,
     RND = 333,
     INT = 334,
     FIX = 335,
     FRAC = 336,
     CINT = 337,
     CSNG = 338,
     CDBL = 339,
     ASC = 340,
     LEFT = 341,
     MID = 342,
     RIGHT = 343,
     LEN = 344,
     STR = 345,
     VAL = 346,
     CHR = 347,
     SEG = 348,
     SUBSTR = 349,
     INSTR = 350,
     AND = 351,
     OR = 352,
     NOT = 353,
     XOR = 354,
     CMP_LE = 355,
     CMP_GE = 356,
     CMP_NE = 357,
     CMP_HASH = 358,
     FRE = 359,
     SPC = 360,
     TAB = 361,
     POS = 362,
     USR = 363,
     LIN = 364,
     DEFSTR = 365,
     DEFINT = 366,
     DEFSNG = 367,
     DEFDBL = 368,
     CHANGE = 369,
     CONVERT = 370,
     UCASE = 371,
     LCASE = 372,
     STRNG = 373,
     TIME = 374,
     TIME_STR = 375,
     HEX = 376,
     OCT = 377,
     BIN = 378,
     HEXSTR = 379,
     OCTSTR = 380,
     BINSTR = 381,
     UBOUND = 382,
     LBOUND = 383,
     LABEL = 384
   };
#endif
/* Tokens.  */
#define STRING 258
#define NUMBER 259
#define DOUBLE 260
#define SINGLE 261
#define INTEGER 262
#define VARIABLE_NAME 263
#define FUNCTION_NAME 264
#define HEX_STR 265
#define OCT_STR 266
#define BIN_STR 267
#define REM 268
#define QUOTEREM 269
#define BANGREM 270
#define BYE 271
#define CLEAR 272
#define CLR 273
#define DATA 274
#define DEF 275
#define DIM 276
#define END 277
#define EXIT 278
#define FOR 279
#define GET 280
#define GOSUB 281
#define GOTO 282
#define IF 283
#define INPUT 284
#define LET 285
#define LIST 286
#define NEXT 287
#define NEW 288
#define OF 289
#define ON 290
#define PRINT 291
#define PUT 292
#define READ 293
#define RESTORE 294
#define RETURN 295
#define RUN 296
#define STEP 297
#define STOP 298
#define THEN 299
#define TO 300
#define USING 301
#define WAIT 302
#define OPEN 303
#define CLOSE 304
#define STATUS 305
#define PRINT_FILE 306
#define INPUT_FILE 307
#define GET_FILE 308
#define PUT_FILE 309
#define CALL 310
#define CLS 311
#define CMD 312
#define OPTION 313
#define BASE 314
#define PEEK 315
#define POKE 316
#define POP 317
#define RANDOMIZE 318
#define SYS 319
#define VARLIST 320
#define PAUSE 321
#define INKEY 322
#define _ABS 323
#define SGN 324
#define ATN 325
#define COS 326
#define SIN 327
#define TAN 328
#define CLOG 329
#define EXP 330
#define LOG 331
#define SQR 332
#define RND 333
#define INT 334
#define FIX 335
#define FRAC 336
#define CINT 337
#define CSNG 338
#define CDBL 339
#define ASC 340
#define LEFT 341
#define MID 342
#define RIGHT 343
#define LEN 344
#define STR 345
#define VAL 346
#define CHR 347
#define SEG 348
#define SUBSTR 349
#define INSTR 350
#define AND 351
#define OR 352
#define NOT 353
#define XOR 354
#define CMP_LE 355
#define CMP_GE 356
#define CMP_NE 357
#define CMP_HASH 358
#define FRE 359
#define SPC 360
#define TAB 361
#define POS 362
#define USR 363
#define LIN 364
#define DEFSTR 365
#define DEFINT 366
#define DEFSNG 367
#define DEFDBL 368
#define CHANGE 369
#define CONVERT 370
#define UCASE 371
#define LCASE 372
#define STRNG 373
#define TIME 374
#define TIME_STR 375
#define HEX 376
#define OCT 377
#define BIN 378
#define HEXSTR 379
#define OCTSTR 380
#define BINSTR 381
#define UBOUND 382
#define LBOUND 383
#define LABEL 384




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 72 "/Volumes/Bigger/Users/maury/Desktop/RetroBASIC/src/parse.y"
{
  double d;
  int i;
  char *s;
  list_t *l;
  statement_t *statement;
  expression_t *expression;
  variable_reference_t *variable;
}
/* Line 1529 of yacc.c.  */
#line 317 "/Volumes/Bigger/Users/maury/Desktop/RetroBASIC/obj/Intermediates.noindex/RetroBASIC.build/Debug/retrobasic.build/DerivedSources/y.tab.h"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE yylval;

